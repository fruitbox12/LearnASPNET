﻿using SQLContactsLibrary;
using SQLContactsLibrary.Models;
using System;
using System.Collections.Generic;
namespace ASP.NET_Console_Project
{
    class ContactView
    {
        private readonly SQLContacts _contacts;

        public ContactView()
        {
            _contacts = new SQLContacts();
        }

        public void DisplayMainMenu()
        {
            string option = "";
            int menuOption = 0;
            while (menuOption != 99)
            {
                Console.WriteLine("Main Menu\n");
                Console.WriteLine("1.\tDisplay Contact List");
                Console.WriteLine("2.\tDisplay Contact List Alphabetically");
                Console.WriteLine("3.\tDisplay Contact List ID order");
                Console.WriteLine("4.\tSearch Contacts List by id");
                Console.WriteLine("5.\tSearch Contacts by Name");
                Console.WriteLine("6.\tSearch Contacts by Email");
                Console.WriteLine("7.\tSearch Contacts by Phone");

                Console.Write("\nEnter your Menu option: -or- Press Enter to Exit ");

                try
                {
                    option = Console.ReadLine();
                    if (option.Length > 0)
                    {
                        menuOption = Int32.Parse(option);
                    }
                    else
                    {
                        menuOption = 99;
                    }
                }

                catch (FormatException e)
                {
                    menuOption = 0;
                }
                switch (menuOption)
                {
                    case 1:
                        DisplayContactList();
                        break;
                    case 2:
                        DisplayContactsByName();
                        break;

                    case 3:
                        DisplayContactsById();
                        break;
                    case 4:
                        SearchContactsById();
                        break;
                    case 5:
                        SearchContactByName();
                        break;
                    case 6:
                        SearchByEmail();
                        break;
                    case 7:
                        SearchContactsByPhoneNumber();
                        break;
                    case 99:
                        Console.WriteLine("\nExiting \n");
                        break;
                    default:
                        Console.WriteLine("\nInvalid Menu Option\n");
                        break;

                }
            }
        }
        private void DisplayContactList()
        {
            Console.WriteLine("\nContact List");


            List<BasicContactModel> basicContactModels = _contacts.GetBasicContactsByName();
            //removed if statement below, basicContactModels is already greater than 0,
            if (basicContactModels.Count > 0)
            {
                Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}", "Id", "First Name", "Middle Name", "Last Name");
                foreach (var basicContactModel in basicContactModels)
                {
                    // C# formatted strings
                    // 1. String Interpolation
                    // 2. Console.Writeline("{0} {1} {2}", rows.Id, rows.FirstName, rows.MiddleName, rows.LastName
                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}", basicContactModel.Id, basicContactModel.FirstName, basicContactModel.MiddleName, basicContactModel.LastName);


                }
                Console.WriteLine("\nThere" + ((basicContactModels.Count == 1) ? " is one Contact " : " are " + basicContactModels.Count + " Contacts ") + "on file");

            }
            else
            {
                Console.WriteLine("The Contacts Database is empty.");
            }
            int numberOfContacts = _contacts.GetNumberOfContacts();

            Console.WriteLine();
        }

        private void DisplayContactsByName()
        {
            Console.WriteLine("\nContacts in Alphabetical Order");
            List<ContactModel> contactModels = _contacts.GetContactsByName();

            if (contactModels.Count > 0)
            {
                Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,15:S}", "Id", "First Name", "Middle Name", "Last Name", "Email Address");
                foreach (var contactModel in contactModels)
                {
                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,15:S}", contactModel.BasicContactModel.Id,
                                                                               contactModel.BasicContactModel.FirstName,
                                                                               contactModel.BasicContactModel.MiddleName,
                                                                               contactModel.BasicContactModel.LastName);

                    if (contactModel.EmailAddress.Count > 0)
                    {
                        Console.WriteLine($"\n\t\t EmailAddresses \n");

                        foreach (var emailAddressModel in contactModel.EmailAddress)
                        {
                            Console.WriteLine($"\t\t { emailAddressModel.EmailAddress} ");
                        }
                    }

                    if (contactModel.PhoneNumber.Count > 0)
                    {
                        Console.WriteLine($"\n\t\t Phone Numbers \n");

                        foreach (var phoneNumberModel in contactModel.PhoneNumber)
                        {
                            Console.WriteLine($"\t\t{ phoneNumberModel.PhoneNumber}");
                            Console.WriteLine();
                        }
                        Console.WriteLine();
                    }

                }
                Console.WriteLine("\nThere" + ((contactModels.Count == 1) ? " is one Contact " : " are " + contactModels.Count + " Contacts ") + "on file");

            }

            Console.WriteLine();
        }
        private void DisplayContactsById()
        {
            Console.WriteLine("\nContacts in Id Order\n");

            List<ContactModel> contactModels = _contacts.GetContactsById();
            if (contactModels.Count > 0)
            {
                Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}", "Id", "First Name", "Middle Name", "Last Name");
                Console.WriteLine();
                foreach (var contactModel in contactModels)
                {


                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}",
                                        contactModel.BasicContactModel.Id,
                                        contactModel.BasicContactModel.FirstName,
                                        contactModel.BasicContactModel.MiddleName,
                                        contactModel.BasicContactModel.LastName);

                    if (contactModel.EmailAddress.Count > 0)
                    {
                        Console.WriteLine($"\n\t\t EmailAddresses \n");

                        foreach (var emailAddressModel in contactModel.EmailAddress)
                        {
                            Console.WriteLine($"\t\t { emailAddressModel.EmailAddress} ");
                        }
                    }

                    if (contactModel.PhoneNumber.Count > 0)
                    {
                        Console.WriteLine($"\n\t\t Phone Numbers \n");

                        foreach (var phoneNumberModel in contactModel.PhoneNumber)
                        {
                            Console.WriteLine($"\t\t{ phoneNumberModel.PhoneNumber}");
                            Console.WriteLine();



                        }
                        Console.WriteLine();

                    }
                }
            }
            else
            {
                Console.WriteLine("The Contacts Database is empty.");

            }
            Console.WriteLine();

        }

        private void SearchContactsById()
        {
            Console.WriteLine("\nSearch Contacts By Id\n");
            int contactId = 0;
            bool finished = false;
            while (!finished)
            {
                try
                {
                    Console.Write("Enter the Contact Id -or- press enter to exit: ");
                    String option = Console.ReadLine();
                    if (option.Length > 0)
                    {
                        contactId = Int32.Parse(option);
                    }
                    else
                    {
                        contactId = 0;
                        finished = true;
                    }
                }

                catch (FormatException e)
                {
                    Console.WriteLine("\nPlease enter a Contact Id number\n");
                    contactId = 0;

                }
                catch (OverflowException e)
                {
                    Console.WriteLine("\nPlease enter a valid Contact Id number\n");
                    contactId = 0;

                }
                if (contactId > 0)
                {
                    BasicContactModel basicContactModel = _contacts.GetBasicContactById(contactId);
                    if (basicContactModel.Id > 0)
                    {
                        Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}", "Id", "First Name", "Middle Name", "Last Name");
                        Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,25:S}",
                                          basicContactModel.Id,
                                          basicContactModel.FirstName,
                                          basicContactModel.MiddleName,
                                          basicContactModel.LastName);
                        Console.WriteLine();

                    }

                    else
                    {
                        Console.WriteLine("\nContact with Id " + contactId + " not found\n");
                    }
                }
            }
            Console.WriteLine();

        }



        private void SearchContactByName()
        {
            Console.WriteLine("\nSearch Contacts By Name\n");

            string firstName = "";
            string lastName = "";

            bool finished = false;

            while (!finished)
            {
                Console.Write("Enter the Contact's First Name Press Enter Twice To Exit: ");
                firstName = Console.ReadLine();

                Console.WriteLine();

                Console.Write("Enter The Contact's Last Name: ");
                lastName = Console.ReadLine();


                if (firstName.Length > 0 || lastName.Length > 0)
                {
                    List<BasicContactModel> basicContactModels = _contacts.SearchBasicContactsByName(firstName, lastName);
                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,15:S}",
                                         "Id",
                                         "First Name",
                                         "Middle Name",
                                         "Last Name");
                    if (basicContactModels.Count > 0)
                    {
                        foreach (var basicContactModel in basicContactModels)
                        {
                            Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,15:S}", basicContactModel.Id, basicContactModel.FirstName,
                                   basicContactModel.MiddleName, basicContactModel.LastName);

                        }
                    }
                    else
                    {
                        Console.WriteLine("\nContact with First Name: " + firstName + " and Last Name: " + lastName + " Not Found\n");
                    }
                    Console.WriteLine();


                }
                else
                {
                    finished = true;
                }
            }
        }
        private void SearchByEmail()
        {
            Console.WriteLine("\nSearch Contact By Email\n");

            string email = "";

            bool finished = false;

            while (!finished)
            {
                Console.Write("Enter the Contact's Email Press Enter To Exit: ");
                email = Console.ReadLine();

                Console.WriteLine();
                if (email.Length > 0)
                {
                    List<EmailAddressModel> emailAddresses = _contacts.SearchEmail(email);
                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,10:S} {4, -50:S}", "Email Address Id", "First Name", "Middle Name", "Last Name", "Email Address");

                    if (emailAddresses.Count > 0)
                    {
                        foreach (var emailAddress in emailAddresses)
                        {
                            BasicContactModel basicContactModel = _contacts.GetBasicContactByEmail(emailAddress.id);

                            Console.WriteLine("{0, -5:D} {1,26:S} {2,15:S} {3,10:S} {4, -40}", emailAddress.id, 
                                                                                               basicContactModel.FirstName,
                                                                                               basicContactModel.MiddleName, 
                                                                                               basicContactModel.LastName, 
                                                                                               emailAddress.EmailAddress);
                            Console.WriteLine("\n{0,50:S}\n", emailAddress.EmailAddress);
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nContact with Email Address: " + email + " Not Found\n");
                    }
                    Console.WriteLine();


                }
                else
                {
                    finished = true;
                }
            }
        }
        private void SearchContactsByPhoneNumber()
        {
            Console.WriteLine("\nSearch Contacts By Phone Number\n");

            string number = "";

            bool finished = false;

            while (!finished)
            {
              
                    Console.Write("Enter the Phone Number -or- press enter to exit: ");
                    number = Console.ReadLine();
                   

                if (number.Length > 0)
                {
                    List<PhoneNumberModel> phoneNumberModels = _contacts.SearchPhoneNumbers(number);
                    Console.WriteLine("{0, -5:D} {1,15:S} {2,15:S} {3,10:S} {4, -50:S}", "Phone Number Id", "First Name", "Middle Name", "Last Name", "Phone Number");

                    if (phoneNumberModels.Count > 0)
                    {
                        foreach (var phoneNumberModel in phoneNumberModels)
                        {
                            BasicContactModel basicContactModel = _contacts.GetBasicContactByPhoneNumber(phoneNumberModel.Id);
                            Console.WriteLine("{0, -5:D} {1,26:S} {2,15:S} {3,10:S} {4, -50}",  phoneNumberModel.Id, 
                                                                                                basicContactModel.FirstName,
                                                                                                basicContactModel.MiddleName, 
                                                                                                basicContactModel.LastName, 
                                                                                                phoneNumberModel.PhoneNumber);
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nContact with Phone Number: " + number + " Not Found\n");
                    }
                    Console.WriteLine();
               
                }
                else
                {
                    finished = true;
                }
            }
        }
    }
        
}


    


