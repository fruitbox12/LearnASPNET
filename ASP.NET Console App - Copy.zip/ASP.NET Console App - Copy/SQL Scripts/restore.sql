USE [SQLContactsDBDylan]
GO
SET IDENTITY_INSERT [dbo].[email_addresses] ON 
GO
INSERT [dbo].[email_addresses] ([id], [email_address]) VALUES (1, N'f23@gmail.com')
GO
INSERT [dbo].[email_addresses] ([id], [email_address]) VALUES (2, N'zz2@gmail.com')
GO
SET IDENTITY_INSERT [dbo].[email_addresses] OFF
GO
SET IDENTITY_INSERT [dbo].[contacts] ON 
GO
INSERT [dbo].[contacts] ([id], [first_name], [middle_name], [last_name]) VALUES (5, N'', N'J', N'')
GO
INSERT [dbo].[contacts] ([id], [first_name], [middle_name], [last_name]) VALUES (6, N'', NULL, N'')
GO
SET IDENTITY_INSERT [dbo].[contacts] OFF
GO
INSERT [dbo].[contact_email_addresses] ([id], [contact_id], [email_id]) VALUES (1, 5, 1)
GO
INSERT [dbo].[contact_email_addresses] ([id], [contact_id], [email_id]) VALUES (2, 6, 2)
GO
SET IDENTITY_INSERT [dbo].[phone_numbers] ON 
GO
INSERT [dbo].[phone_numbers] ([id], [phone_number]) VALUES (3, N'31292929222')
GO
INSERT [dbo].[phone_numbers] ([id], [phone_number]) VALUES (1, N'80021321321')
GO
SET IDENTITY_INSERT [dbo].[phone_numbers] OFF
GO
SET IDENTITY_INSERT [dbo].[contact_phone_numbers] ON 
GO
INSERT [dbo].[contact_phone_numbers] ([id], [contact_id], [phone_number_id]) VALUES (4, 5, 1)
GO
INSERT [dbo].[contact_phone_numbers] ([id], [contact_id], [phone_number_id]) VALUES (5, 6, 3)
GO
SET IDENTITY_INSERT [dbo].[contact_phone_numbers] OFF
GO
