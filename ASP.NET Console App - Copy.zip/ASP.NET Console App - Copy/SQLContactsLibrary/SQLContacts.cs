﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SQLContactsLibrary.Models;
using DataAccessLibrary;
using Microsoft.Extensions.Configuration;

namespace SQLContactsLibrary
{
    public class SQLContacts
    {
        private readonly SQLDataAccess _dataAccess;

        public SQLContacts()
        {
            _dataAccess = new SQLDataAccess();
        }

        // Getters
        public int GetNumberOfContacts()
        {
            string sqlStatement = "SELECT COUNT (*) FROM dbo.contacts;";
            return _dataAccess.Count(sqlStatement);
        }

        public BasicContactModel GetBasicContactById(int contactId)
        {
            // Use @ paramater instead of concating string valiues in SQL statements
            /// TheParameters prevent sql injection hacks https://www.w3schools.com/sql/sql_injection.asp

            //   basiccontactmodel is not found, a new model is created
            BasicContactModel basicContactModel;
            string sqlStatement = @"SELECT id AS Id, first_name AS FirstName, middle_name AS MiddleName, last_name AS LastName
                                    FROM dbo.contacts WHERE id = @Id;";
            basicContactModel = _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { Id = contactId }).FirstOrDefault();


            if (basicContactModel == null)
            {
                basicContactModel = new BasicContactModel();
            }
           
            return basicContactModel;
        }
        public List<ContactModel> GetContactsById()
        {
            List<ContactModel> contactModels = new List<ContactModel>();

            List<BasicContactModel> basicContactModels = GetBasicContactsById();

            foreach (var basicContactModel in basicContactModels)
            {
                ContactModel contactModel = new ContactModel();
                contactModel.BasicContactModel = basicContactModel;
                // retrieve all email addresses 
                contactModel.EmailAddress = GetEmailAddresses(basicContactModel.Id);
                // retrieve all phone numbers 
                contactModel.PhoneNumber = GetPhoneNumbers(basicContactModel.Id);
                contactModels.Add(contactModel);
            }
            return contactModels;
        }
        public List<BasicContactModel> GetBasicContactsByName()
        {
            // Using @ sign instead of string concation 
            string sqlStatement = @"SELECT id AS Id, first_name AS FirstName, middle_name AS MiddleName, last_name AS LastName
                                    FROM dbo.contacts ORDER BY last_name, first_name ASC;";
            return _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { });
        }
  

        public List<BasicContactModel> GetBasicContactsById()
        {
            //  @ sign opposed to string concation
            string sqlStatement = @"SELECT id AS Id, first_name AS FirstName, middle_name AS MiddleName, last_name AS LastName
                                    FROM dbo.contacts;";
            return _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { });
        }


        // Integrated Solutions
        public List<ContactModel> GetContactsByName()
        {
            List<ContactModel> contactModels = new List<ContactModel>();
            List<BasicContactModel> basicContactModels = GetBasicContactsByName();

            if (basicContactModels.Count > 0)
            {
                foreach (var basicContactModel in basicContactModels)
                {
                    ContactModel contactModel = new ContactModel();
                    contactModel.BasicContactModel = basicContactModel;
                    // Get the Contact's Email Addresses
                    contactModel.EmailAddress = GetEmailAddresses(basicContactModel.Id);
                    // Get the Contact's Phone Numbers
                    contactModel.PhoneNumber = GetPhoneNumbers(basicContactModel.Id);
                    contactModels.Add(contactModel);
                }
            }
            return contactModels;
        }
        public List<BasicContactModel> SearchBasicContactsByName(string firstName, string lastName)
        {
            // USe @ paramater instead of concating string valiues in SQL statements
            // Parameters prevent sql injection hacks https://www.w3schools.com/sql/sql_injection.asp

            // if no id for basiccontantmodel is not found, null will be returned
            string sqlStatement;
             sqlStatement = @"SELECT id AS Id, first_name AS FirstName, last_name AS LastName
                                    FROM dbo.contacts 
                                    WHERE first_name LIKE @firstName AND last_name LIKE @lastName;";


            return _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { FirstName = "%" + firstName + "%", LastName = "%" + lastName + "%" });
        }

        public List<EmailAddressModel> SearchEmail(string emailAddress)
        {

            //the correct query stored in my sqlscripts folder
            // i must finish implementing
            string sqlStatement = @"SELECT id AS Id, email_address AS EmailAddress
                                    FROM dbo.email_addresses                           
                                    WHERE email_address LIKE @emailAddress;";





            return _dataAccess.Read<EmailAddressModel, dynamic>(sqlStatement, new { EmailAddress = "%" + emailAddress + "%" });
        }
        public BasicContactModel GetBasicContactByEmail(int emailAddressId)
        {

            // if no id for basiccontantmodel is not found, null will be returned
            string sqlStatement;
            sqlStatement =           @"SELECT first_name AS FirstName, middle_name AS MiddleName, last_name AS LastName
                                    FROM dbo.contacts AS c
                                    INNER JOIN dbo.contacts_email_addresses AS ce
                                    ON ce.contact_id = c.id
                                    WHERE ce.email_id = @Id;";
            return  _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { Id = emailAddressId }).FirstOrDefault();

        }


        public List<EmailAddressModel> GetEmailAddresses(int contactId)
        {
            // retrieve all email addresses for this contact
            String sqlStatement = @"SELECT e.id AS Id, e.email_address as EmailAddress
                                FROM dbo.email_addresses AS e
                                INNER JOIN dbo.contacts_email_addresses as ce
                                ON e.id = ce.email_id
                                WHERE ce.contact_id = @Id;";
            return _dataAccess.Read<EmailAddressModel, dynamic>(sqlStatement, new { Id = contactId });
        }

        public List<PhoneNumberModel> GetPhoneNumbers(int contactId)
        {
            // retrieve all email addresses for this contact
            String sqlStatement = @"SELECT p.id AS Id, p.phone_number as PhoneNumber   
                                FROM dbo.phone_numbers AS p
                                INNER JOIN dbo.contacts_phone_numbers as cp
                                ON p.id = cp.phone_number_id
                                WHERE cp.contact_id = @Id;";
            return _dataAccess.Read<PhoneNumberModel, dynamic>(sqlStatement, new { Id = contactId });
        }

        public List<PhoneNumberModel> SearchPhoneNumbers(string phoneNumber)
        {
            // USe @ paramater instead of concating string valiues in SQL statements
            // Parameters prevent sql injection hacks https://www.w3schools.com/sql/sql_injection.asp

            // if no id for basiccontantmodel is not found, null will be returned
           
            string sqlStatement = @"SELECT id AS Id, phone_number AS PhoneNumber
                                FROM dbo.phone_numbers                            
                                WHERE phone_number LIKE @phoneNumber;";
              


            return _dataAccess.Read<PhoneNumberModel, dynamic>(sqlStatement, new { PhoneNumber = "%" + phoneNumber + "%" });
        }

        public BasicContactModel GetBasicContactByPhoneNumber(int phoneNumberId)
        {
            string sqlStatement = @"SELECT first_name AS FirstName, middle_name AS MiddleName, last_name as LastName 
                                    FROM dbo.contacts AS c
                                    INNER JOIN dbo.contacts_phone_numbers  AS cp
                                    ON cp.contact_id = c.id
                                    WHERE cp.phone_number_id = @Id;";
            return _dataAccess.Read<BasicContactModel, dynamic>(sqlStatement, new { Id = phoneNumberId }).FirstOrDefault();

        }

    

        private string GetConnectionString(string connectionString = "Default")
        {
            string connection = "";
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json"); return connection;
        }
    }
}
