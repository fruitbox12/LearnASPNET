﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SQLContactsLibrary.Models
{
   public class EmailAddressModel
    {

        public int id { get; set; }
        public string EmailAddress { get; set; } = "";
    }
}
