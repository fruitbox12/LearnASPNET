﻿namespace ASP.NET_Console_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            ContactView view = new ContactView();
            view.DisplayMainMenu();

               
        }
    }
}
